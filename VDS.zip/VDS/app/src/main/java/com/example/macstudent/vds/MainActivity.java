package com.example.macstudent.vds;

import android.Manifest;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.speech.RecognizerIntent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.net.URI;
import java.security.Permission;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView mTextView;
    private final int SPEECHREQUESTCODE = 534;
    PermissionListener phonePermissionListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createPermissionListener();

        // permission : show the permission popup box

        Dexter.withActivity(this)
                .withPermission(Manifest.permission.CALL_PHONE)
                .withListener(phonePermissionListener)
                .check();
    }

 public class MAinActivity extends AppCompatActivity{
        private TextView mTextView;
        private final int SPEECH_REQUEST_CODE= 808;



    }

 public  void createPermissionListener(){

        if(phonePermissionListener == null){
            phonePermissionListener = new PermissionListener() {
                @Override
                public void onPermissionGranted(PermissionGrantedResponse response) {

                }

                @Override
                public void onPermissionDenied(PermissionDeniedResponse response) {
                    mTextView.setText("App need to work properly!");
                }

                @Override
                public void onPermissionRationaleShouldBeShown(PermissionRequest permission, PermissionToken token) {
                     token.continuePermissionRequest();
                }
            };



        }
 }
    // UI Setup user interface

    public void dialphonenumber(String number) {
        // 1. get the phone number which android understand

        Log.d("ankit", "what number?  " + number);
        String phonrnumber = "tel:" + number;

        //2. make the phone call


        // a. create a phone dialler intent

        Intent dialerIntent = new Intent(Intent.ACTION_CALL);

        //b. configure the intent

        dialerIntent.setData(Uri.parse(phonrnumber));

        //c. start the intent
        startActivity(dialerIntent);
    }

    public void buttonpressed(View view) {

        // put the code for speech to text in here


        // 1. you: start the google speech

        // a. create a new intent
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        // b. OPTIONAL : configure the intent

        // this is the default microphone popup box
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);

        // configure the message on the microphone popup box
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "What color is the sky?");


        //c. start the intent

        try {
            // show the popup box
            startActivityForResult(intent, SPEECHREQUESTCODE);
        } catch (ActivityNotFoundException a) {
            // Sometimes you are using a phone that doesn't have speech to text functions
            // If this happens, then show error message.
            String msg = "Your phone doesn't support speech to text.";
            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();


            //2. Google : Listen and wait for person to finish speech


            //3. GOOgle : Google automatically translate speech


            //4. YOU : Do Something with their text

        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == SPEECHREQUESTCODE) {
            if (resultCode == RESULT_OK) {

                // get results from speech recognizer and save to a list / array
                List<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);

                // get the first item in the list -> this is what
                // google thinks the person said
                String answer = results.get(0);
                Log.d("ankit", answer);

                dialphonenumber(answer);
                //mTextView.setText("You said: " + answer);

               // dialphonenumber(answer);
                /*
                if (answer.indexOf("blue") > -1)
                    Toast.makeText(this, "You win!", Toast.LENGTH_SHORT).show();
                else {
                    Toast.makeText(this, "Wrong!", Toast.LENGTH_SHORT).show();
                }
                */
            }
        }
    }
}


